# Hodgkin-Huxley
Modelo computacional del disparo de una neurona

Es el código base para la práctica correspondiente.
Está prohibido compartir soluciones con compañeros o estudiantes fuera del curso.

El cuaderno solicitará los archivos:
* styles/bmh_matplotlibrc.json
* styles/custom.css

se recomienda descargarlos del repositorio [styles](https://github.com/computacion-ciencias/styles.git), colocándolo al lado de éste y actualizar la liga suave a ellos si es necesario, de modo que, si los estilos son actualizados, los cambios tengan efecto automáticamente.

